#include <iostream>
#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/*
    Alumno: Felipe Sepulveda Galvez
    Rut: 19.034.264-6
    Programa utilizado desde el escritorio con el archivo "numeros.txt" dentro de la carpeta de este proyecto
*/

using namespace std;

//Algoritmo de ordenamiento por insercion
void insercionDirecta(float A[],int n)
{

      int i,j;
      float v;

      for (i = 1; i < n; i++)
        {
             v = A[i];
             j = i - 1;
             while (j >= 0 && A[j] > v)
             {
                  A[j + 1] = A[j];
                  j--;
             }

             A[j + 1] = v;
      }
}

void muestraCadena(int cant, float n[])
{
    int i;
    for(i=0;i<cant;i++)
    {
        if (i == cant-1){
            cout<<n[i]<<endl;
        }else{
            cout<<n[i]<<" - ";
        }
    }
}

float mediana(int lon, float v[])
{
	if (lon%2)
		return(v[lon/2]);

	else
		return((v[(lon/2)-1]+v[lon/2])/2);
}

int main()
{
    FILE *archivo;
    int cant = 0;//inicializa contador
    float lista[99999], beta, x=1, suma=0, media=0;
    char num[4];

    archivo = fopen("numeros.txt", "r"); //abre archivo con datos

    while (x != EOF)
    {
        //cout<<"\n=======INICIO DEL PROCESO======"<<endl;

        x = fscanf(archivo, "%s", num);

        //cambia "," por ".", en las notas del archivo
        for(int j=0; j<2; j++){
            if (num[j]== ','){
                num[j]='.';
                break;
            }
        }

        beta = atof(num);
        if (x != EOF){
        lista[cant] = beta;
        suma = suma + beta;
        cant++;
        /*
        cout<<"#########LISTA SIN ORDENAR##########"<<endl;
        muestraCadena(cant,lista);
        insercionDirecta(lista,cant);
        cout<<"##########LISTA ORDENADA############"<<endl;
        muestraCadena(cant,lista);
        cout<<"=========================================="<<endl;
        */
        media = suma/cant;
        float med = mediana(cant,lista);
        //if ((cant%1000)==0){
            cout<<beta<<" / Cant:"<<cant<<" / Suma:"<<suma<<" / Media: "<<media<<" / Mediana: "<<med<<endl;
        //}

        }

        //cout<<"\n========FIN DEL PROCESO======="<<endl;
    }
    fclose(archivo);

}
